/* sail_sat.c
 * Implementation of the satellite communication module.
 * Created on August 23, 2016.
 * Created by Thomas Gwynne-Timothy.
 */

//if unused should remove
 #include "sail_sat.h"
 
 