/* sail_sat.h
 * Header file for the satellite communication module.
 * Created on August 23, 2016.
 * Created by Thomas Gwynne-Timothy.

 */


//if unused should remove
#ifndef SAIL_SAT_H_
#define SAIL_SAT_H_




#endif /* SAIL_SAT_H_ */